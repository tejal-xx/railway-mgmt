
import mysql.connector
import os
import datetime
import time
from mysql.connector import DataError
import random

current_date = datetime.date.today()

def Menu(answer="Yes"):

    if answer in ["Yes", "Y"]:
        print("1. Book a Ticket")
        print("2. Cancel a Booking")
        print("3. Show my Bookings")
        print("4. Show Available Trains")
        print("5. Clear Screen")
        print("6. Menu")
        print("7. Exit")
    else:
        pass

def AvailableTrains():
    

    mn = mysql.connector.connect(host="localhost", user="tejal",
                                 password="tollboothticket", database="railway")
    cur = mn.cursor()

    print("Enter the Station Codes")
    start_opt = input("From: ")
    final_opt = input("To: ")
    date = input("Date(YYYY-MM-DD): ")
    date_user = datetime.datetime.strptime(date, "%Y-%m-%d").date()
   # while date_user < current_date:
    #    print("Please enter a Valid Date!")
     #   date = input("Date(DD/MM/YYYY): ")
      #  date_user = datetime.datetime.(date, "%Y-%m-%d").date()
       # date_user = date_user.date()

    cur.execute(
        'SELECT Train_No, Source_Station_Name, Destination_Station_Name, Arrival_Time, Departure_Time from train_info where Source_Station_Code="{}" AND Destination_Station_Code="{}";'.format(
            start_opt, final_opt))
    result = cur.fetchall()
    os.system("cls")
  #  time.sleep(1)
   # head = ["Train_No", "Source_Station_Name",
     #       "Destination_Station_Name", "Arrival_Time", "Departure_Time"]

    if len(result) == 0:
        print("No Trains Available!")
    else:
        print(["Train_No", "Source_Station_Name",
            "Destination_Station_Name", "Arrival_Time", "Departure_Time"])
        print(" ")
        for x in result:
            print(x, "\n")

    cur.close()
    mn.close()

def ShowBookings():
    

    mn = mysql.connector.connect(host="localhost", user="tejal",
                                 password="tollboothticket", database="railway")
    cur = mn.cursor()

    mobile_no = input("Enter your 10 Digit Mobile Number: ")

    cur.execute('SELECT * FROM bookings where Mobile_No="{}"'.format(mobile_no))

    result = cur.fetchall()
    if len(result) == 0:
        print("No Records Found!")
    else:
        booking_no = 1
        print(["Train_No", "Passenger_Name", "Mobile_No", "Time_Of_Booking", "Booking_ID", "Class"])
        for x in result:
            print("BOOKING NO", booking_no, ":", x, "\n")
            booking_no += 1

    cur.close()
    mn.close()


def BookTrain():
    
    mn = mysql.connector.connect(host="localhost", user="tejal",
                                 password="tollboothticket", database="railway")
    cur = mn.cursor()
    
    train_no = int(input("Train Number: "))

    Name = input("Enter your Name: ")

    Mobile = int(input("Enter your Mobile Number: "))

    Time_of_Booking = datetime.datetime.now()
    date = Time_of_Booking.date()
    date = date.strftime("%d-%m-%y")

    id = random.randint(1, 10000)
    cur.execute("SELECT Booking_ID FROM BOOKINGS")
    result = cur.fetchall()
    seater_class="any"
    Used_ID = []
    for x in result:
        for y in x:
            Used_ID.append(y)
    while True:
        if id in Used_ID:
            id = random.randint(1, 10000)
        else:
            break

   # while True:
      #  ask = input("Are you Sure you want to Book(Y/N): ")
      #  if ask in ["Y", "y"]:
    print("Booking...")
    try:
        query = "INSERT INTO bookings values({}, '{}', '{}', '{}', {}, '{}')".format(train_no, Name, Mobile, date, id, seater_class)
        cur.execute(query)
    except DataError:
        print("Error in Booking!")
    else:
        print("Successfully Booked!")
        mn.commit()
        cur.close()
        mn.close()            
        
     #   elif ask in ["N", "n"]:
      ##      time.sleep(0.5)
       #     break
      #  else:
      #      print("Please Enter Y (Yes) or N (No)!")


def CancelBooking():
   
    mn = mysql.connector.connect(host="localhost", user="tejal",
                                 password="tollboothticket", database="railway")
    cur = mn.cursor()

    unique_id = int(input("Enter the Unique ID: "))
    cur.execute("SELECT * FROM bookings WHERE Booking_ID={}".format(unique_id))
    result = cur.fetchall()
    if len(result) == 0:
        print("No Records Found!")
        
    print(["Train_No", "Passenger_Name", "Mobile_No", "Time_Of_Booking", "Booking_ID"])
    for x in result:
        print(x)
        
    cur.execute("DELETE FROM bookings WHERE Booking_ID={}".format(unique_id))
    print("Deleted!")
    mn.commit()
    cur.close()
   # mn.close()
    ##   try:
      ##     print("Please Enter a Valid ID!")
        #else:
         ##      print("Invalid ID!")
           # elif unique_id < 1:
           #     print("ID Out of Range!")
            #elif unique_id > 10000:
             #   print("ID Out of Range!")
            #elif len(str(unique_id)) != 0 and unique_id >= 1 and unique_id <= 10000:
            #    cur.execute(
             ##   result = cur.fetchall()
             #   if len(result) == 0:
             #       print("No Records Found!")
             #       break
             #   print(["Train_No", "Passenger_Name", "Mobile_No", "Time_Of_Booking", "Booking_ID"])
             #   for x in result:
              #      print(x)
              #  while True:
                 ##   if ask in ["Y", "y"]:
                   #     cur.execute(
                   #         "DELETE FROM bookings WHERE Booking_ID={}".format(unique_id))
                   #     print("Deleted!")
                   #     mn.commit()
                   ##     mn.close()
                    #  e#lif ask in ["N", "n"]:
                    #    break
                    #else:
                   #     print("Please Enter either Y (Yes) or N (No)!")
              #  break
        #    else:
        #        print("Please Enter a Valid ID!")
