
import core.User_Functions as User

import core.Checks as Check
from time import sleep


connection_status = Check.CheckConnection()
if connection_status is False:
    quit()
else:
    Check.CheckDatabase()  



#User.Menu()

while True:
    print("welcome ot menu")
    User.Menu()
    ans = input("Choose an Option Number: ")
    if ans == "1":
        User.BookTrain()
    elif ans == "2":
        User.CancelBooking()
    elif ans == "3":
        User.ShowBookings()
    elif ans == "4":
        User.AvailableTrains()
    elif ans == "5":
        User.Menu()
    elif ans == "6":
        User.Menu()
    elif ans == "7":
        print("Closing all Connections..")
        sleep(0.5)
        print("Thank You!")
        quit()
    else:
        print("Please Enter a Valid Option Number!")
